"""Common helper functions."""
