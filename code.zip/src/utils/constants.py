"""Project-wide constants."""
