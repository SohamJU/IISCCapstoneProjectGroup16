"""Shared utility tools."""
