"""Handles product-related queries."""
