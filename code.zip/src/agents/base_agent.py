"""Base agent abstraction."""
