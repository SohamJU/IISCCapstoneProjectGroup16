"""Coordinates agent execution."""
