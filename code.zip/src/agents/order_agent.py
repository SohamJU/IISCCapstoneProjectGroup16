"""Handles order-related queries."""
